package com.soyeon.app.repository;

import com.soyeon.app.entity.Interests;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InterestsRepository extends JpaRepository<Interests, Long> {
}
